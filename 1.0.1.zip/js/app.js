﻿// 页面加载完成后执行
document.addEventListener("DOMContentLoaded", function() {
    // 初始化变量
    let currentPage = 1;
    let isLoading = false;
    const pageSize = 10;

    // 获取DOM元素
    const searchInput = document.querySelector(".search-bar input");
    const searchBtn = document.querySelector(".search-btn");
    const tabs = document.querySelectorAll(".tab");
    const filterItems = document.querySelectorAll(".filter-item");
    const houseList = document.querySelector(".house-list");

    // 搜索功能
    searchBtn.addEventListener("click", function() {
        const keyword = searchInput.value.trim();
        if (keyword) {
            searchHouses(keyword);
        }
    });

    // 回车搜索
    searchInput.addEventListener("keyup", function(event) {
        if (event.key === "Enter") {
            const keyword = searchInput.value.trim();
            if (keyword) {
                searchHouses(keyword);
            }
        }
    });

    // 标签切换
    tabs.forEach(tab => {
        tab.addEventListener("click", function() {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            filterHouses(this.textContent);
        });
    });

    // 筛选条件变化
    filterItems.forEach(item => {
        item.addEventListener("change", function() {
            applyFilters();
        });
    });

    // 滚动加载更多
    window.addEventListener("scroll", function() {
        if (isLoading) return;
        
        if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 100) {
            loadMoreHouses();
        }
    });

    // 模拟搜索房源
    function searchHouses(keyword) {
        console.log("搜索房源:", keyword);
        // 调用原生方法进行搜索
        if (window.AndroidInterface && window.AndroidInterface.searchHouses) {
            window.AndroidInterface.searchHouses(keyword);
        }
    }

    // 模拟筛选房源
    function filterHouses(category) {
        console.log("筛选房源:", category);
        // 调用原生方法进行筛选
        if (window.AndroidInterface && window.AndroidInterface.filterHouses) {
            window.AndroidInterface.filterHouses(category);
        }
    }

    // 应用筛选条件
    function applyFilters() {
        const filters = Array.from(filterItems).map(item => item.value);
        console.log("应用筛选:", filters);
        // 调用原生方法应用筛选
        if (window.AndroidInterface && window.AndroidInterface.applyFilters) {
            window.AndroidInterface.applyFilters(JSON.stringify(filters));
        }
    }

    // 加载更多房源
    function loadMoreHouses() {
        isLoading = true;
        console.log("加载更多房源，页码:", currentPage + 1);
        
        // 模拟加载数据
        setTimeout(() => {
            // 这里应该调用原生方法获取数据
            if (window.AndroidInterface && window.AndroidInterface.loadMoreHouses) {
                window.AndroidInterface.loadMoreHouses(currentPage + 1, pageSize);
            } else {
                // 模拟数据用于测试
                const mockData = {
                    title: "测试房源",
                    location: "测试地址",
                    price: "300万",
                    tags: ["测试标签1", "测试标签2"]
                };
                appendHouseItem(mockData);
            }
            
            currentPage++;
            isLoading = false;
        }, 1000);
    }

    // 添加房源项到列表
    function appendHouseItem(data) {
        const houseItem = document.createElement("div");
        houseItem.className = "house-item";
        houseItem.innerHTML = `
            <img src="images/house-default.jpg" alt="房源图片">
            <div class="house-info">
                <h3>${data.title}</h3>
                <p class="location">${data.location}</p>
                <p class="price">${data.price}</p>
                <p class="tags">
                    ${data.tags.map(tag => `<span>${tag}</span>`).join("")}
                </p>
            </div>
        `;
        
        // 点击房源项跳转到详情页
        houseItem.addEventListener("click", function() {
            if (window.AndroidInterface && window.AndroidInterface.openHouseDetail) {
                window.AndroidInterface.openHouseDetail(data.id);
            } else {
                window.location.href = `detail.html?id=${data.id}`;
            }
        });
        
        houseList.appendChild(houseItem);
    }

    // 初始化页面数据
    loadMoreHouses();
});
