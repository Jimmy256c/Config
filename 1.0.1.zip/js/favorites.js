﻿// 页面加载完成后执行
document.addEventListener("DOMContentLoaded", function() {
    // 获取DOM元素
    const editBtn = document.getElementById("editBtn");
    const actionBar = document.getElementById("actionBar");
    const selectAll = document.getElementById("selectAll");
    const deleteBtn = document.getElementById("deleteBtn");
    const favoritesList = document.getElementById("favoritesList");
    const checkboxes = document.querySelectorAll(".select-item");

    let isEditMode = false;

    // 初始化收藏列表
    loadFavorites();

    // 编辑按钮点击事件
    editBtn.addEventListener("click", function() {
        isEditMode = !isEditMode;
        toggleEditMode();
    });

    // 全选按钮点击事件
    selectAll.addEventListener("change", function() {
        const checkboxes = document.querySelectorAll(".select-item");
        checkboxes.forEach(checkbox => {
            checkbox.checked = this.checked;
        });
        updateDeleteButton();
    });

    // 删除按钮点击事件
    deleteBtn.addEventListener("click", function() {
        if (confirm("确定要删除选中的收藏吗？")) {
            const selectedItems = Array.from(document.querySelectorAll(".select-item:checked"))
                .map(checkbox => checkbox.closest(".house-item"))
                .map(item => item.dataset.id);

            // 调用原生方法删除收藏
            if (window.AndroidInterface && window.AndroidInterface.deleteFavorites) {
                window.AndroidInterface.deleteFavorites(JSON.stringify(selectedItems));
            }

            // 从DOM中移除选中的项
            selectedItems.forEach(id => {
                const item = document.querySelector(`.house-item[data-id="${id}"]`);
                if (item) {
                    item.remove();
                }
            });

            // 更新全选状态和删除按钮
            selectAll.checked = false;
            updateDeleteButton();
            
            // 如果删除后列表为空，退出编辑模式
            if (favoritesList.children.length === 0) {
                isEditMode = false;
                toggleEditMode();
            }
        }
    });

    // 重写返回事件处理
    window.handleBack = function() {
        if (isEditMode) {
            // 如果在编辑模式，先退出编辑模式
            isEditMode = false;
            toggleEditMode();
            return;
        }
        
        // 不在编辑模式，执行正常返回
        if (window.AndroidInterface && typeof window.AndroidInterface.goBack === 'function') {
            window.AndroidInterface.goBack();
        } else {
            window.location.href = 'profile.html';
        }
    };

    // 加载收藏列表
    function loadFavorites() {
        // 调用原生方法获取收藏列表
        if (window.AndroidInterface && window.AndroidInterface.getFavorites) {
            const favorites = window.AndroidInterface.getFavorites();
            try {
                const list = JSON.parse(favorites);
                renderFavorites(list);
            } catch (e) {
                console.error("Parse favorites failed:", e);
            }
        }
    }

    // 渲染收藏列表
    function renderFavorites(list) {
        favoritesList.innerHTML = "";
        list.forEach(item => {
            const houseItem = document.createElement("div");
            houseItem.className = "house-item";
            houseItem.dataset.id = item.id;
            houseItem.innerHTML = `
                <div class="checkbox" style="display: none;">
                    <input type="checkbox" class="select-item">
                </div>
                <img src="${item.image || 'images/house-default.jpg'}" alt="房源图片">
                <div class="house-info">
                    <h3>${item.title}</h3>
                    <p class="location">${item.location}</p>
                    <p class="price">${item.price}</p>
                    <p class="tags">
                        ${item.tags.map(tag => `<span>${tag}</span>`).join("")}
                    </p>
                </div>
            `;

            // 点击房源项跳转到详情页
            houseItem.addEventListener("click", function(e) {
                if (!isEditMode || e.target.type !== "checkbox") {
                    if (window.AndroidInterface && window.AndroidInterface.openHouseDetail) {
                        window.AndroidInterface.openHouseDetail(item.id);
                    } else {
                        window.location.href = `detail.html?id=${item.id}`;
                    }
                }
            });

            favoritesList.appendChild(houseItem);
        });

        // 绑定checkbox事件
        document.querySelectorAll(".select-item").forEach(checkbox => {
            checkbox.addEventListener("change", updateDeleteButton);
        });
    }

    // 切换编辑模式
    function toggleEditMode() {
        editBtn.textContent = isEditMode ? "完成" : "编辑";
        actionBar.style.display = isEditMode ? "flex" : "none";
        document.querySelectorAll(".checkbox").forEach(checkbox => {
            checkbox.style.display = isEditMode ? "block" : "none";
        });
        if (!isEditMode) {
            // 退出编辑模式时取消所有选中状态
            selectAll.checked = false;
            document.querySelectorAll(".select-item").forEach(checkbox => {
                checkbox.checked = false;
            });
        }
    }

    // 更新删除按钮状态
    function updateDeleteButton() {
        const checkedCount = document.querySelectorAll(".select-item:checked").length;
        deleteBtn.disabled = checkedCount === 0;
        selectAll.checked = checkedCount === checkboxes.length && checkedCount !== 0;
    }
});
