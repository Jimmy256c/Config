﻿// 页面加载完成后执行
document.addEventListener("DOMContentLoaded", function() {
    // 获取DOM元素
    const loginBtn = document.getElementById("loginBtn");
    const userAvatar = document.getElementById("userAvatar");
    const userName = document.getElementById("userName");
    const userLevel = document.getElementById("userLevel");
    const contactSupport = document.getElementById("contactSupport");

    // 检查登录状态
    checkLoginStatus();

    // 登录按钮点击事件
    loginBtn.addEventListener("click", function() {
        // 调用原生登录方法
        if (window.AndroidInterface && window.AndroidInterface.login) {
            window.AndroidInterface.login();
        }
    });

    // 联系客服点击事件
    contactSupport.addEventListener("click", function() {
        // 调用原生方法打开客服聊天
        if (window.AndroidInterface && window.AndroidInterface.openCustomerService) {
            window.AndroidInterface.openCustomerService();
        }
    });

    // 检查登录状态
    function checkLoginStatus() {
        // 调用原生方法获取用户信息
        if (window.AndroidInterface && window.AndroidInterface.getUserInfo) {
            const userInfo = window.AndroidInterface.getUserInfo();
            if (userInfo) {
                try {
                    const info = JSON.parse(userInfo);
                    updateUserInfo(info);
                } catch (e) {
                    console.error("Parse user info failed:", e);
                }
            }
        }
    }

    // 更新用户信息
    function updateUserInfo(info) {
        if (info.avatar) {
            userAvatar.src = info.avatar;
        }
        if (info.name) {
            userName.textContent = info.name;
        }
        if (info.level) {
            userLevel.textContent = info.level;
        }
        if (info.isLogin) {
            loginBtn.style.display = "none";
        }
    }

    // 注册原生回调方法
    window.updateUserInfo = updateUserInfo;
});
