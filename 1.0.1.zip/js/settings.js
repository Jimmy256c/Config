﻿// 页面加载完成后执行
document.addEventListener("DOMContentLoaded", function() {
    // 获取DOM元素
    const pushNotification = document.getElementById("pushNotification");
    const soundNotification = document.getElementById("soundNotification");
    const logoutBtn = document.getElementById("logoutBtn");
    const settingsItems = document.querySelectorAll(".settings-item");
    const cacheSize = document.querySelector(".cache-size");

    // 初始化设置状态
    initSettings();

    // 推送通知开关事件
    pushNotification.addEventListener("change", function() {
        // 调用原生方法设置推送通知
        if (window.AndroidInterface && window.AndroidInterface.setPushNotification) {
            window.AndroidInterface.setPushNotification(this.checked);
        }
    });

    // 声音提醒开关事件
    soundNotification.addEventListener("change", function() {
        // 调用原生方法设置声音提醒
        if (window.AndroidInterface && window.AndroidInterface.setSoundNotification) {
            window.AndroidInterface.setSoundNotification(this.checked);
        }
    });

    // 退出登录按钮点击事件
    logoutBtn.addEventListener("click", function() {
        if (confirm("确定要退出登录吗？")) {
            // 调用原生方法退出登录
            if (window.AndroidInterface && window.AndroidInterface.logout) {
                window.AndroidInterface.logout();
            }
        }
    });

    // 设置项点击事件
    settingsItems.forEach(item => {
        item.addEventListener("click", function() {
            const type = this.querySelector("span").textContent;
            handleSettingClick(type);
        });
    });

    // 初始化设置状态
    function initSettings() {
        // 获取缓存大小
        if (window.AndroidInterface && window.AndroidInterface.getCacheSize) {
            const size = window.AndroidInterface.getCacheSize();
            cacheSize.textContent = size;
        }

        // 获取通知设置状态
        if (window.AndroidInterface && window.AndroidInterface.getNotificationSettings) {
            const settings = window.AndroidInterface.getNotificationSettings();
            try {
                const { push, sound } = JSON.parse(settings);
                pushNotification.checked = push;
                soundNotification.checked = sound;
            } catch (e) {
                console.error("Parse notification settings failed:", e);
            }
        }
    }

    // 处理设置项点击
    function handleSettingClick(type) {
        switch(type) {
            case "修改密码":
                if (window.AndroidInterface && window.AndroidInterface.changePassword) {
                    window.AndroidInterface.changePassword();
                }
                break;
            case "实名认证":
                if (window.AndroidInterface && window.AndroidInterface.verifyIdentity) {
                    window.AndroidInterface.verifyIdentity();
                }
                break;
            case "手机绑定":
                if (window.AndroidInterface && window.AndroidInterface.bindPhone) {
                    window.AndroidInterface.bindPhone();
                }
                break;
            case "清除缓存":
                if (confirm("确定要清除缓存吗？")) {
                    if (window.AndroidInterface && window.AndroidInterface.clearCache) {
                        window.AndroidInterface.clearCache();
                        cacheSize.textContent = "0MB";
                    }
                }
                break;
            case "检查更新":
                if (window.AndroidInterface && window.AndroidInterface.checkUpdate) {
                    window.AndroidInterface.checkUpdate();
                }
                break;
            case "用户协议":
                if (window.AndroidInterface && window.AndroidInterface.openUserAgreement) {
                    window.AndroidInterface.openUserAgreement();
                }
                break;
            case "隐私政策":
                if (window.AndroidInterface && window.AndroidInterface.openPrivacyPolicy) {
                    window.AndroidInterface.openPrivacyPolicy();
                }
                break;
            case "关于平台":
                if (window.AndroidInterface && window.AndroidInterface.openAboutUs) {
                    window.AndroidInterface.openAboutUs();
                }
                break;
        }
    }
});
